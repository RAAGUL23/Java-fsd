package inheritance;

public class Y extends X {
	
		public void methodY(){
		System.out.println("class Y method");
	}
	}

