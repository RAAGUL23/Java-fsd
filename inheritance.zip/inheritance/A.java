package inheritance;

public class A {
		   public void methodA()
		   {
		     System.out.println("Base class method");
		   }
		   }



