package pet;

public class Dog {
		   String breed;
		   int age;
		   String color;

		   void barking() {
		   }
		   void hungry() {
		   }

		   void sleeping() {
		   }}

